@php
$isEdit = isset($college);
$field = fn($name,$default='') => old($name, $default);
$rows = function($key,$fallback=[]) use ($isEdit) {
$old = old($key);
if (is_array($old)) return $old;
return $fallback;
};
$arr = fn($v) => is_array($v) ? $v : (blank($v) ? [] : (is_string($v) ? (json_decode($v,true) ?: []) : []));
@endphp

<style>
    .gp-admin-form {
        --n: #002B67;
        --nd: #001B45;
        --b: #174B8F;
        --g: #008A43;
        --gd: #006B35;
        --gold: #D9A400;
        --border: #E2E8F0;
        --text: #172033;
        --muted: #68758A;
        max-width: 1600px;
        margin: auto
    }

    .gp-hero {
        background: linear-gradient(135deg, var(--nd), var(--n) 58%, var(--b));
        color: #fff;
        border-radius: 18px;
        padding: 22px 24px;
        margin-bottom: 16px
    }

    .gp-hero h2 {
        margin: 7px 0 4px;
        font-size: 1.35rem;
        font-weight: 800
    }

    .gp-hero p {
        margin: 0;
        color: #d9e5f5;
        font-size: .75rem
    }

    .gp-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 300px;
        gap: 16px;
        align-items: start
    }

    .gp-card {
        background: #fff;
        border: 1px solid var(--border);
        border-radius: 15px;
        margin-bottom: 16px;
        overflow: hidden;
        box-shadow: 0 7px 22px rgba(20, 35, 60, .05)
    }

    .gp-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 13px 16px;
        border-bottom: 1px solid var(--border);
        background: #fbfcfe
    }

    .gp-title {
        margin: 0;
        font-size: .83rem;
        font-weight: 800;
        color: var(--text)
    }

    .gp-sub {
        font-size: .59rem;
        color: var(--muted)
    }

    .gp-body {
        padding: 16px
    }

    .gp-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 11px
    }

    .gp-grid3 {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px
    }

    .gp-field label {
        display: block;
        font-size: .62rem;
        font-weight: 800;
        color: #445066;
        margin-bottom: 5px
    }

    .gp-control {
        width: 100%;
        border: 1px solid #d8e1eb;
        border-radius: 8px;
        padding: 8px 9px;
        font-size: .72rem;
        background: #fff;
        outline: 0
    }

    .gp-control:focus {
        border-color: var(--b);
        box-shadow: 0 0 0 3px rgba(23, 75, 143, .08)
    }

    .gp-repeater {
        border: 1px solid #e2e8f0;
        border-radius: 11px;
        padding: 11px;
        margin-bottom: 10px;
        background: #fcfdff
    }

    .gp-repeater-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 9px
    }

    .gp-row-actions {
        display: flex;
        gap: 6px
    }

    .gp-btn {
        border: 0;
        border-radius: 7px;
        padding: 7px 10px;
        font-size: .66rem;
        font-weight: 800;
        cursor: pointer
    }

    .gp-add {
        background: #eaf2fb;
        color: var(--b)
    }

    .gp-remove {
        background: #fff0f0;
        color: #b42318
    }

    .gp-save {
        background: var(--g);
        color: #fff;
        width: 100%;
        padding: 12px;
        border: 0;
        border-radius: 9px;
        font-weight: 800
    }

    .gp-sticky {
        position: sticky;
        top: 15px
    }

    .gp-help {
        font-size: .62rem;
        color: var(--muted);
        line-height: 1.5
    }

    .gp-check {
        display: flex;
        gap: 7px;
        align-items: center;
        font-size: .68rem
    }

    .gp-preview {
        max-width: 110px;
        max-height: 70px;
        border-radius: 7px;
        border: 1px solid var(--border);
        object-fit: cover;
        margin-top: 6px
    }

    .gp-alert {
        padding: 10px 12px;
        border-radius: 9px;
        margin-bottom: 12px;
        font-size: .72rem
    }

    .gp-alert.err {
        background: #fff1f0;
        color: #9f1239
    }

    .gp-alert.ok {
        background: #ecfdf3;
        color: #166534
    }

    @media(max-width:1050px) {
        .gp-layout {
            grid-template-columns: 1fr
        }

        .gp-sticky {
            position: static
        }
    }

    @media(max-width:680px) {

        .gp-grid,
        .gp-grid3 {
            grid-template-columns: 1fr
        }

        .gp-body {
            padding: 12px
        }

        .gp-hero {
            padding: 18px
        }

        .gp-head {
            padding: 11px 12px
        }
    }
</style>

<div class="gp-admin-form">
    <div class="gp-hero">
        <div style="font-size:.62rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase">GrowPEC College Manager</div>
        <h2>{{ $isEdit ? 'Edit College' : 'Add New College' }}</h2>
        <p>Manage basic information, courses, admission, placements, scholarships, facilities, gallery, alumni, reviews, comparison and SEO from one responsive admin form.</p>
    </div>

    @if($errors->any())
    <div class="gp-alert err"><strong>Please fix these errors:</strong>
        <ul style="margin:5px 0 0 18px">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
    </div>
    @endif
    @if(session('success'))<div class="gp-alert ok">{{ session('success') }}</div>@endif

    <form method="POST" action="{{ $isEdit ? route('admin.colleges.update',$college->id) : route('admin.colleges.store') }}" enctype="multipart/form-data" id="collegeAdminForm">
        @csrf
        @if($isEdit) @method('PUT') @endif

        <div class="gp-layout">
            <main>
                <section class="gp-card">
                    <div class="gp-head">
                        <div>
                            <h3 class="gp-title">Basic College Information</h3>
                            <div class="gp-sub">Identity, mode, branding and SEO</div>
                        </div>
                    </div>
                    <div class="gp-body">
                        <div class="gp-grid">
                            <div class="gp-field"><label>College Name *</label><input class="gp-control" name="name" value="{{ $field('name',$isEdit?$college->name:'') }}" required></div>
                            <div class="gp-field"><label>Short Name</label><input class="gp-control" name="short_name" value="{{ $field('short_name',$isEdit?$college->short_name:'') }}"></div>
                            <div class="gp-field"><label>Mode *</label><select class="gp-control" name="college_mode" required>
                                    <option value="regular" {{ $field('college_mode',$isEdit?$college->college_mode:'regular')=='regular'?'selected':'' }}>Regular</option>
                                    <option value="online" {{ $field('college_mode',$isEdit?$college->college_mode:'')=='online'?'selected':'' }}>Online</option>
                                    <option value="both" {{ $field('college_mode',$isEdit?$college->college_mode:'')=='both'?'selected':'' }}>Both</option>
                                </select></div>
                            <div class="gp-field"><label>College Type *</label><select class="gp-control" name="college_type" required>@foreach(['Govt','Private','Deemed','Autonomous'] as $t)<option {{ $field('college_type',$isEdit?$college->college_type:'Private')==$t?'selected':'' }}>{{ $t }}</option>@endforeach</select></div>
                            <div class="gp-field"><label>University / Affiliation</label><input class="gp-control" name="university_name" value="{{ $field('university_name',$isEdit?$college->university_name:'') }}"></div>
                            <div class="gp-field"><label>Website</label><input class="gp-control" type="url" name="website" value="{{ $field('website',$isEdit?$college->website:'') }}"></div>
                            <div class="gp-field"><label>NAAC Grade</label><input class="gp-control" name="naac_grade" value="{{ $field('naac_grade',$isEdit?$college->naac_grade:'') }}"></div>
                            <div class="gp-field"><label>NIRF Rank</label><input class="gp-control" type="number" name="nirf_rank" value="{{ $field('nirf_rank',$isEdit?$college->nirf_rank:'') }}"></div>
                            <div class="gp-field"><label>NIRF Year</label><input class="gp-control" type="number" name="nirf_year" value="{{ $field('nirf_year',$isEdit?$college->nirf_year:'') }}"></div>
                            <div class="gp-field"><label>Rating (0-5)</label><input class="gp-control" type="number" step=".1" min="0" max="5" name="rating" value="{{ $field('rating',$isEdit?$college->rating:'') }}"></div>
                            <div class="gp-field"><label>Reviews Count</label><input class="gp-control" type="number" min="0" name="reviews_count" value="{{ $field('reviews_count',$isEdit?$college->reviews_count:0) }}"></div>
                            <div class="gp-field"><label>Established Year</label><input class="gp-control" name="established_year" value="{{ $field('established_year',$isEdit?$college->established_year:'') }}"></div>
                        </div>
                        <div class="gp-grid" style="margin-top:11px">
                            <div class="gp-field"><label>Overview</label><textarea class="gp-control" name="overview" rows="5">{{ $field('overview',$isEdit?$college->overview:'') }}</textarea></div>
                            <div class="gp-field"><label>Admission Process (Legacy Summary)</label><textarea class="gp-control" name="admission_process" rows="5">{{ $field('admission_process',$isEdit?$college->admission_process:'') }}</textarea></div>
                        </div>
                        <div class="gp-grid" style="margin-top:11px">
                            <div class="gp-field"><label>SEO Title</label><input class="gp-control" name="seo_title" value="{{ $field('seo_title',$isEdit?$college->seo_title:'') }}"></div>
                            <div class="gp-field"><label>SEO Description</label><textarea class="gp-control" name="seo_description" rows="2">{{ $field('seo_description',$isEdit?$college->seo_description:'') }}</textarea></div>
                        </div>
                    </div>
                </section>

                <section class="gp-card">
                    <div class="gp-head">
                        <div>
                            <h3 class="gp-title">Images & Documents</h3>
                            <div class="gp-sub">Hero, logo, certificate and brochure</div>
                        </div>
                    </div>
                    <div class="gp-body">
                        <div class="gp-grid">
                            @foreach([['banner_image','Banner Image','image/*'],['logo','College Logo','image/*'],['sample_certificate_image','Sample Certificate','image/*'],['brochure_pdf','Brochure PDF','.pdf']] as $f)
                            <div class="gp-field"><label>{{ $f[1] }}</label><input class="gp-control" type="file" name="{{ $f[0] }}" accept="{{ $f[2] }}">
                                @if($isEdit && !empty($college->{$f[0]}))<div class="gp-help" style="margin-top:4px">Existing file: {{ basename($college->{$f[0]}) }}</div>@endif
                            </div>
                            @endforeach
                        </div>
                    </div>
                </section>

                <section class="gp-card">
                    <div class="gp-head">
                        <div>
                            <h3 class="gp-title">Courses, Fees & Specializations</h3>
                            <div class="gp-sub">Course mapping + fee + eligibility + specialization mapping</div>
                        </div><button type="button" class="gp-btn gp-add" data-add="course">+ Add Course</button>
                    </div>
                    <div class="gp-body">
                        <div id="coursesRepeater">
                            @php $courseRows = $isEdit ? $college->collegeCourses : [null]; @endphp
                            @foreach($courseRows as $i=>$cc)
                            @php
                            $selectedSpecIds = [];
                            if ($cc) {
                            $selectedSpecIds = $cc->specializationMappings
                            ->pluck('specialization_id')
                            ->map(fn($id) => (string) $id)
                            ->values()
                            ->all();

                            if (!$selectedSpecIds && $cc->specialization_id) {
                            $selectedSpecIds = [(string) $cc->specialization_id];
                            }
                            }

                            $selectedSpecIds = old("specialization_map.{$i}", $selectedSpecIds);
                            $selectedSpecIds = array_map('strval', (array) $selectedSpecIds);
                            @endphp
                            <div class="gp-repeater course-item" data-index="{{ $i }}">
                                <div class="gp-repeater-head"><strong style="font-size:.7rem">Course #{{ $i+1 }}</strong><button type="button" class="gp-btn gp-remove" data-remove>Remove</button></div>
                                <div class="gp-grid3">
                                    <div class="gp-field"><label>Stream</label><select class="gp-control stream-select">
                                            <option value="">Select Stream</option>@foreach($streams as $stream)<option value="{{ $stream->id }}" {{ $cc && optional($cc->course)->stream_id==$stream->id?'selected':'' }}>{{ $stream->name }}</option>@endforeach
                                        </select></div>
                                    <div class="gp-field"><label>Course *</label><select class="gp-control course-select" name="course_ids[]" required>
                                            <option value="">Select Course</option>@foreach($courses as $course)<option value="{{ $course->id }}" data-stream="{{ $course->stream_id }}" {{ $cc && $cc->course_id==$course->id?'selected':'' }}>{{ $course->name }}</option>@endforeach
                                        </select></div>
                                    <div class="gp-field"><label>Fee Amount</label><input class="gp-control" type="number" step=".01" name="fee_amounts[]" value="{{ $cc->fee_amount ?? '' }}"></div>
                                    <div class="gp-field"><label>Fee Type</label><select class="gp-control" name="fee_types[]">
                                            <option value="per_year" {{ $cc && ($cc->fee_type ?? '')==='per_year'?'selected':'' }}>Per Year</option>
                                            <option value="per_semester" {{ $cc && ($cc->fee_type ?? '')==='per_semester'?'selected':'' }}>Per Semester</option>
                                            <option value="total_course" {{ $cc && ($cc->fee_type ?? '')==='total_course'?'selected':'' }}>Total Course</option>
                                        </select></div>
                                    <div class="gp-field"><label>Eligibility</label><input class="gp-control" name="eligibilities[]" value="{{ $cc->eligibility ?? '' }}"></div>
                                    <div class="gp-field"><label>Academic Session</label><input class="gp-control" name="academic_sessions[]" value="{{ $cc->academic_session ?? '' }}"></div>
                                    <div class="gp-field"><label>Duration</label><input class="gp-control" name="durations[]" value="{{ $cc->duration ?? '' }}"></div>
                                    <div class="gp-field"><label>Application URL</label><input class="gp-control" type="text" name="application_urls[]" placeholder="https://example.com or /contact" value="{{ $cc->application_url ?? '' }}">
                                        <div class="gp-help">Internal paths like <code>/contact</code> are allowed.</div>
                                    </div>
                                </div>
                                <div class="gp-field" style="margin-top:9px">
                                    <label>Specializations <span class="gp-help">(database linked • multiple allowed)</span></label>
                                    <select class="gp-control specialization-select" multiple size="4" name="specialization_map[{{ $i }}][]">
                                        @foreach($courses as $course)
                                        @if($course->specializations && $course->specializations->count())
                                        @foreach($course->specializations as $sp)
                                        <option value="{{ $sp->id }}" data-course="{{ $course->id }}" {{ in_array((string) $sp->id, $selectedSpecIds, true) ? 'selected' : '' }}>{{ $sp->name }}</option>
                                        @endforeach
                                        @endif
                                        @endforeach
                                    </select>
                                    <div class="gp-help" style="margin-top:5px">Only specializations belonging to the selected Course are shown.</div>
                                </div>
                                <div class="gp-field" style="margin-top:9px">
                                    <label>Additional Fee Lines (optional)</label>
                                    <div class="fee-lines">
                                        @php
                                            $feeRows = $cc && $cc->fees && $cc->fees->count()
                                                ? $cc->fees
                                                : collect([null]);
                                        @endphp
                                        @foreach($feeRows as $feeIndex => $fee)
                                        <div class="gp-grid3 fee-line">
                                            <input class="gp-control"
                                                   placeholder="Fee name"
                                                   name="course_fee_lines[{{ $i }}][{{ $feeIndex }}][fee_name]"
                                                   value="{{ $fee->label ?? '' }}">
                                            <input class="gp-control"
                                                   type="number"
                                                   step=".01"
                                                   placeholder="Amount"
                                                   name="course_fee_lines[{{ $i }}][{{ $feeIndex }}][amount]"
                                                   value="{{ $fee->amount ?? '' }}">
                                            <input class="gp-control"
                                                   placeholder="Notes"
                                                   name="course_fee_lines[{{ $i }}][{{ $feeIndex }}][notes]"
                                                   value="{{ $fee->description ?? '' }}">
                                        </div>
                                        @endforeach
                                    </div>
                                    <div class="gp-help" style="margin-top:5px">
                                        Fee lines are stored in the course fee table as Label, Amount and Description.
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </section>

                @include('admin.colleges._advanced_sections', ['college' => $college ?? null, 'allColleges'=>$allColleges ?? collect()])
            </main>

            <aside class="gp-sticky">
                <section class="gp-card">
                    <div class="gp-head">
                        <div>
                            <h3 class="gp-title">Location & Status</h3>
                            <div class="gp-sub">Visibility and public profile</div>
                        </div>
                    </div>
                    <div class="gp-body">
                        <div class="gp-field"><label>State *</label><select class="gp-control" name="state" id="stateSelect" required>
                                <option value="">Select State</option>@foreach($states as $st)<option value="{{ $st->name }}" data-id="{{ $st->id }}" {{ $field('state',$isEdit?$college->state:'')==$st->name?'selected':'' }}>{{ $st->name }}</option>@endforeach
                            </select></div>
                        <div class="gp-field" style="margin-top:10px"><label>City *</label><select class="gp-control" name="city" id="citySelect" data-current-city="{{ $field('city',$isEdit?$college->city:'') }}" required>
                                <option value="{{ $field('city',$isEdit?$college->city:'') }}">{{ $field('city',$isEdit?$college->city:'Select City') }}</option>
                            </select></div>
                        <div class="gp-field" style="margin-top:10px"><label>Address</label><textarea class="gp-control" name="address" rows="3">{{ $field('address',$isEdit?$college->address:'') }}</textarea></div>
                        <div class="gp-field" style="margin-top:10px"><label>Campus Size</label><input class="gp-control" name="campus_size" value="{{ $field('campus_size',$isEdit?$college->campus_size:'') }}"></div>
                        <div class="gp-field" style="margin-top:10px"><label>Approvals / Badges</label><input class="gp-control" name="approvals" value="{{ $field('approvals',$isEdit?$college->approvals:'') }}"></div>
                        <div class="gp-field" style="margin-top:10px"><label>Entrance Exams</label><input class="gp-control" name="entrance_exams" value="{{ $field('entrance_exams',$isEdit?$college->entrance_exams:'') }}"></div>
                        <label class="gp-check" style="margin-top:11px"><input type="hidden" name="ugc_approved" value="0"><input type="checkbox" name="ugc_approved" value="1" {{ $field('ugc_approved',$isEdit?$college->ugc_approved:0)?'checked':'' }}> UGC Approved</label>
                        <label class="gp-check" style="margin-top:8px"><input type="checkbox" name="has_boys_hostel" value="1" {{ $field('has_boys_hostel',$isEdit?$college->has_boys_hostel:0)?'checked':'' }}> Boys Hostel</label>
                        <label class="gp-check" style="margin-top:8px"><input type="checkbox" name="has_girls_hostel" value="1" {{ $field('has_girls_hostel',$isEdit?$college->has_girls_hostel:0)?'checked':'' }}> Girls Hostel</label>
                        <label class="gp-check" style="margin-top:8px"><input type="checkbox" name="is_featured" value="1" {{ $field('is_featured',$isEdit?$college->is_featured:0)?'checked':'' }}> Featured College</label>
                        <label class="gp-check" style="margin-top:8px"><input type="checkbox" name="status" value="1" {{ $field('status',$isEdit?$college->status:1)?'checked':'' }}> Public / Active</label>
                        <button class="gp-save" type="submit" style="margin-top:14px">{{ $isEdit ? 'Update College' : 'Create College' }}</button>
                        <a href="{{ route('admin.colleges.index') }}" style="display:block;text-align:center;margin-top:8px;font-size:.68rem;color:#64748b">Cancel</a>
                    </div>
                </section>
            </aside>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        function bindCourse(item) {
            var stream = item.querySelector('.stream-select');
            var course = item.querySelector('.course-select');
            var specs = item.querySelector('.specialization-select');

            if (!stream || !course) return;

            function refreshSpecializations() {
                if (!specs) return;
                var courseId = course.value;

                Array.prototype.forEach.call(specs.options, function(option) {
                    var belongsToCourse = option.getAttribute('data-course') === courseId;
                    option.hidden = !belongsToCourse;
                    if (!belongsToCourse) option.selected = false;
                });
            }

            function refreshCourses() {
                var streamId = stream.value;
                var currentCourse = course.value;

                Array.prototype.forEach.call(course.options, function(option) {
                    if (!option.value) return;
                    option.hidden = !!streamId && option.getAttribute('data-stream') !== streamId;
                });

                var selectedOption = Array.prototype.find.call(course.options, function(option) {
                    return option.value === currentCourse && !option.hidden;
                });

                if (!selectedOption && streamId) course.value = '';
                refreshSpecializations();
            }

            stream.addEventListener('change', refreshCourses);
            course.addEventListener('change', refreshSpecializations);
            refreshCourses();
        }

        document.querySelectorAll('.course-item').forEach(bindCourse);

        var addCourseButton = document.querySelector('[data-add="course"]');
        if (addCourseButton) {
            addCourseButton.addEventListener('click', function() {
                var wrap = document.getElementById('coursesRepeater');
                var src = wrap ? wrap.querySelector('.course-item') : null;
                if (!wrap || !src) return;

                var indexes = Array.prototype.map.call(
                    wrap.querySelectorAll('.course-item'),
                    function(item) {
                        return parseInt(item.getAttribute('data-index') || '-1', 10);
                    }
                );
                var idx = indexes.length ? Math.max.apply(null, indexes) + 1 : 0;
                var clone = src.cloneNode(true);
                clone.dataset.index = idx;

                clone.querySelectorAll('input').forEach(function(input) {
                    input.value = '';
                });

                clone.querySelectorAll('select').forEach(function(select) {
                    Array.prototype.forEach.call(select.options, function(option) {
                        option.selected = false;
                        option.hidden = false;
                    });
                    select.selectedIndex = 0;
                });

                clone.querySelectorAll('[name]').forEach(function(element) {
                    element.name = element.name.replace(/\[\d+\]/g, '[' + idx + ']');
                });

                clone.querySelector('.gp-repeater-head strong').textContent = 'Course #' + (idx + 1);
                wrap.appendChild(clone);
                bindCourse(clone);
            });
        }

        document.addEventListener('click', function(event) {
            var removeButton = event.target.closest('[data-remove]');
            if (!removeButton) return;

            var item = removeButton.closest('.course-item');
            if (item && document.querySelectorAll('.course-item').length > 1) item.remove();
        });

        var state = document.getElementById('stateSelect');
        var city = document.getElementById('citySelect');
        var currentCity = city ? (city.getAttribute('data-current-city') || '') : '';

        function loadCities(id, selected) {
            if (!id || !city) return;

            fetch('/api/states/' + id + '/cities')
                .then(function(response) {
                    return response.json();
                })
                .then(function(list) {
                    city.innerHTML = '';
                    var first = document.createElement('option');
                    first.value = '';
                    first.textContent = 'Select City';
                    city.appendChild(first);

                    list.forEach(function(c) {
                        var option = document.createElement('option');
                        option.value = c.name;
                        option.textContent = c.name;
                        if (c.name === selected) option.selected = true;
                        city.appendChild(option);
                    });
                });
        }

        if (state) {
            state.addEventListener('change', function() {
                var selected = state.options[state.selectedIndex];
                var stateId = selected ? selected.getAttribute('data-id') : '';
                loadCities(stateId, '');
            });

            var selectedState = state.options[state.selectedIndex];
            var initialStateId = selectedState ? selectedState.getAttribute('data-id') : '';
            if (initialStateId) loadCities(initialStateId, currentCity);
        }
    });
</script>