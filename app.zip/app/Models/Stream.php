<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Stream extends Model
{
    protected $fillable = ['name', 'slug', 'icon'];

    public function courses(): HasMany
    {
        return $this->hasMany(Course::class);
    }
}